// Axios with React
import React, { useEffect, useState } from 'react';
import axios from 'axios';

const DataFetchingComponent = () => {
    const [data, setData] = useState([]);

    useEffect(() => {
        axios.get('https://api.example.com/data')
            .then(response => setData(response.data))
            .catch(error => console.error(error));
    }, []);

    return (
        <ul>
            {data.map(item => <li key={item.id}>{item.name}</li>)}
        </ul>
    );
};

axios.get('https://api.example.com/data')
    .then(response => console.log(response.data))
    .catch(error => {
        if (error.response) {
            // Server responded with a status other than 200
            console.error('Error:', error.response.status);
        } else {
            // Network error
            console.error('Error:', error.message);
        }
    });
