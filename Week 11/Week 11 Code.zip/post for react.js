import React, { useState, useEffect } from 'react';
import axios from 'axios';

function App() {
    const [data, setData] = useState([]);
    const [name, setName] = useState('');
    const [age, setAge] = useState('');
    const [email, setEmail] = useState('');
    const [error, setError] = useState('');

    const fetchData = async () => {
        const response = await axios.get('http://localhost:3000/data');
        setData(response.data);
    };

    const postData = async () => {
        setError(''); // Reset error message
        try {
            // Create JSON payload
            const payload = { name, age: Number(age), email };
            // Send JSON payload to the server
            await axios.post('http://localhost:3000/data', payload);
            fetchData(); // Refresh data after posting
            setName(''); // Clear input
            setAge('');
            setEmail('');
        } catch (error) {
            setError(error.response ? error.response.data : 'Error posting data');
        }
    };

    useEffect(() => {
        fetchData(); // Fetch data on component mount
    }, []);

    return (
        <div>
            <h1>Data</h1>
            {error && <p style={{ color: 'red' }}>{error}</p>}
            <ul>
                {data.map((item, index) => (
                    <li key={index}>{item.name} - {item.age} - {item.email}</li>
                ))}
            </ul>
            <input
                type="text"
                value={name}
                onChange={(e) => setName(e.target.value)}
                placeholder="Enter name"
            />
            <input
                type="number"
                value={age}
                onChange={(e) => setAge(e.target.value)}
                placeholder="Enter age"
            />
            <input
                type="email"
                value={email}
                onChange={(e) => setEmail(e.target.value)}
                placeholder="Enter email"
            />
            <button onClick={postData}>Submit</button>
        </div>
    );
}

export default App;
