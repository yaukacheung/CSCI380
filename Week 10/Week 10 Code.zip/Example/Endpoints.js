// Securing API Endpoints

server.route({
    method: 'GET',
    path: '/users',
    options: {
        auth: 'jwt' // Protect this endpoint
    },
    handler: (request, h) => {
        return 'User data';
    }
});
