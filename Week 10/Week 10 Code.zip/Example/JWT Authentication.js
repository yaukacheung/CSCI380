// Setting Up JWT Authentication

const Jwt = require('@hapi/jwt');

server.auth.strategy('jwt', 'jwt', {
    keys: 'your_secret_key',
    validate: (decoded, request) => {
        return { isValid: true }; // Add your validation logic here
    }
});

server.auth.default('jwt');

server.route({
    method: 'GET',
    path: '/protected',
    handler: (request, h) => {
        return 'This is a protected route';
    }
});
