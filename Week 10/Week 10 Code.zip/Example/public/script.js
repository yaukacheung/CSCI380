const bookForm = document.getElementById('bookForm');
const bookList = document.getElementById('bookList');

// Fetch and display books
const fetchBooks = async () => {
    const response = await fetch('http://localhost:3000/books', {
        method: 'GET',
        headers: {
            'Authorization': 'Bearer your_jwt_secret' // Update with a valid JWT
        }
    });

    if (response.ok) {
        const books = await response.json();
        bookList.innerHTML = '';
        books.forEach(book => {
            const li = document.createElement('li');
            li.textContent = `${book.title} by ${book.author} - $${book.price}`;
            bookList.appendChild(li);
            console.log(bookList);
        });
        console.log(bookList);
    } else {
        console.error('Failed to fetch books');
    }
};

// Add a new book
bookForm.addEventListener('submit', async (event) => {
    event.preventDefault();
    const title = document.getElementById('title').value;
    const author = document.getElementById('author').value;
    const price = document.getElementById('price').value;

    const response = await fetch('/books', {
        method: 'POST',
        headers: {
            'Content-Type': 'application/json',
            'Authorization': 'Bearer your_jwt_secret' // Update with a valid JWT
        },
        body: JSON.stringify({ title, author, price })
    });

    if (response.ok) {
        fetchBooks();
        bookForm.reset();
    } else {
        console.error('Failed to add book');
    }
});

// Initial fetch
fetchBooks();
