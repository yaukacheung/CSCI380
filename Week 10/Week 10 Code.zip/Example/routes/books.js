const Joi = require('joi');
const Book = require('../models/Book');
const { authenticate } = require('../auth/auth');

const bookSchema = Joi.object({
  title: Joi.string().required(),
  author: Joi.string().required(),
  price: Joi.number().required(),
});

const init = (server) => {
  server.route([
    {
      method: 'POST',
      path: '/books',
      options: {
        auth: false, // change to 'required' when JWT is implemented
        validate: {
          payload: bookSchema,
        },
      },
      handler: async (request, h) => {
        const book = new Book(request.payload);
        await book.save();
        return h.response(book).code(201);
      },
    },
    {
      method: 'GET',
      path: '/books',
      options: {
        pre: [{ method: authenticate }],
      },
      handler: async (request, h) => {
        const books = await Book.find();
        return h.response(books).code(200);
      },
    },
  ]);
};

module.exports = { init };
