const jwt = require('jsonwebtoken');
const dotenv = require('dotenv');

dotenv.config();

const authenticate = (req, h) => {
  const token = req.headers['authorization']?.split(' ')[1];
  
  if (!token) {
    return h.response({ message: 'Unauthorized' }).code(401).takeover();
  }
  
  try {
    const decoded = jwt.verify(token, process.env.JWT_SECRET);
    req.user = decoded;
    return h.continue;
  } catch (err) {
    return h.response({ message: 'Unauthorized' }).code(401).takeover();
  }
};

module.exports = { authenticate };
