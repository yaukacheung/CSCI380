// npm install joi --save

const Hapi = require('@hapi/hapi');
const Joi = require('joi');

const init = async () => {
    const server = Hapi.server({
        port: 3000,
        host: 'localhost'
    });

    server.route({
        method: 'POST',
        path: '/submit',
        handler: (request, h) => {
            return `Data received: ${JSON.stringify(request.payload)}`;
        },
        options: {
            validate: {
                payload: Joi.object({
                    name: Joi.string().min(3).required(),
                    email: Joi.string().email().required()
                })
            }
        }
    });

    await server.start();
    console.log('Server running on %s', server.info.uri);
};

init();

// curl -X POST http://localhost:3000/submit -H "Content-Type: application/json" -d '{"name": "AB", "email": "ab@gmail.com"}'