import styles from "./App.module.css";

// replace nav style inline with:
<nav className={styles.nav}>
  <Link to="/">Home</Link>
  <Link to="/about">About</Link>
  <Link to="/contact">Contact</Link>
</nav>
