import { BrowserRouter as Router, Routes, Route, Link } from "react-router-dom";
import { ThemeProvider, useTheme } from "./context/ThemeContext";
import Home from "./pages/Home";
import Posts from "./pages/Posts";

function Navbar() {
  const { darkMode, toggleTheme } = useTheme();

  return (
    <nav style={{ background: darkMode ? "#333" : "#eee", padding: "10px" }}>
      <Link to="/">Home</Link> | <Link to="/posts">Posts</Link>
      <button onClick={toggleTheme} style={{ marginLeft: "10px" }}>
        {darkMode ? "Light Mode" : "Dark Mode"}
      </button>
    </nav>
  );
}

function App() {
  return (
    <ThemeProvider>
      <Router>
        <Navbar />
        <Routes>
          <Route path="/" element={<Home />} />
          <Route path="/posts" element={<Posts />} />
        </Routes>
      </Router>
    </ThemeProvider>
  );
}

export default App;
