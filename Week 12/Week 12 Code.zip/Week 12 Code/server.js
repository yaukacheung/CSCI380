// server.js
// npm install @hapi/hapi mongoose @hapi/joi @hapi/boom dotenv
'use strict'; // All code in this file will run in strict mode

require('dotenv').config();
const Hapi = require('@hapi/hapi');
const dbPlugin = require('./config/db');
const userRoutes = require('./routes/users');

const init = async () => {
  const server = Hapi.server({
    port: process.env.PORT || 3000,
    host: 'localhost'
  });

  // register mongoose plugin with MONGO_URI from env
  await server.register({
    plugin: dbPlugin,
    options: { uri: process.env.MONGO_URI }
  });

  // Register routes (array)
  server.route(userRoutes);

  // Simple health route
  server.route({
    method: 'GET',
    path: '/health',
    handler: (request, h) => ({ status: 'ok', uptime: process.uptime() })
  });

  await server.start();
  console.log(`Server running at: ${server.info.uri}`);
};

// Handle graceful shutdown
process.on('unhandledRejection', (err) => {
  console.error(err);
  process.exit(1);
});

init();
