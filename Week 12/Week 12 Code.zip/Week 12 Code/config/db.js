// config/db.js
'use strict';
const mongoose = require('mongoose');

exports.plugin = {
  name: 'mongoose-connector',
  register: async (server, options) => {
    const uri = options.uri;
    if (!uri) throw new Error('MONGO_URI is required for mongoose plugin');

    mongoose.set('strictQuery', true); // optional
    try {
      await mongoose.connect(uri);
      server.log(['info'], 'Mongoose connected');
    } catch (err) {
      server.log(['error'], 'Mongoose connection error: ' + err.message);
      throw err;
    }

    // close mongoose on server stop
    server.ext('onPostStop', async () => {
      await mongoose.disconnect();
      server.log(['info'], 'Mongoose disconnected');
    });
  }
};
