// routes/users.js
'use strict';
const Joi = require('@hapi/joi');
const Boom = require('@hapi/boom');
const User = require('../models/User');

const userPayloadSchema = Joi.object({
  name: Joi.string().min(2).required(),
  email: Joi.string().email().required(),
  role: Joi.string().optional()
});

module.exports = [
  // GET /users  (with optional ?role=admin filter)
  {
    method: 'GET',
    path: '/users',
    handler: async (request, h) => {
      const { role } = request.query;
      const filter = role ? { role } : {};
      const users = await User.find(filter).sort({ createdAt: -1 }).lean();
      return h.response(users);
    },
    options: {
      validate: {
        query: Joi.object({ role: Joi.string().optional() })
      },
      tags: ['api']
    }
  },

  // GET /users/{id}
  {
    method: 'GET',
    path: '/users/{id}',
    handler: async (request, h) => {
      const { id } = request.params;
      try {
        const user = await User.findById(id).lean();
        if (!user) throw Boom.notFound('User not found');
        return h.response(user);
      } catch (err) {
        // invalid ObjectId or other DB error
        if (err.name === 'CastError') throw Boom.badRequest('Invalid user id');
        throw Boom.internal(err.message);
      }
    },
    options: {
      validate: {
        params: Joi.object({ id: Joi.string().required() })
      },
      tags: ['api']
    }
  },

  // POST /users
  {
    method: 'POST',
    path: '/users',
    handler: async (request, h) => {
      const { error, value } = userPayloadSchema.validate(request.payload);
      if (error) return Boom.badRequest(error.details[0].message);

      try {
        const user = new User(value);
        await user.save();
        return h.response(user).code(201);
      } catch (err) {
        // handle duplicate email error
        if (err.code === 11000) return Boom.conflict('Email already exists');
        throw Boom.internal(err.message);
      }
    },
    options: {
      validate: {
        payload: userPayloadSchema,
        failAction: (request, h, err) => { throw err; } // show validation error
      },
      tags: ['api']
    }
  },

  // PUT /users/{id}
  {
    method: 'PUT',
    path: '/users/{id}',
    handler: async (request, h) => {
      const { id } = request.params;
      const { error, value } = userPayloadSchema.validate(request.payload);
      if (error) return Boom.badRequest(error.details[0].message);

      try {
        const updated = await User.findByIdAndUpdate(id, value, { new: true, runValidators: true }).lean();
        if (!updated) throw Boom.notFound('User not found');
        return h.response(updated);
      } catch (err) {
        if (err.name === 'CastError') throw Boom.badRequest('Invalid user id');
        throw Boom.internal(err.message);
      }
    },
    options: {
      validate: {
        params: Joi.object({ id: Joi.string().required() }),
        payload: userPayloadSchema
      },
      tags: ['api']
    }
  },

  // DELETE /users/{id}
  {
    method: 'DELETE',
    path: '/users/{id}',
    handler: async (request, h) => {
      const { id } = request.params;
      try {
        const deleted = await User.findByIdAndDelete(id).lean();
        if (!deleted) throw Boom.notFound('User not found');
        return h.response({ message: 'User deleted' });
      } catch (err) {
        if (err.name === 'CastError') throw Boom.badRequest('Invalid user id');
        throw Boom.internal(err.message);
      }
    },
    options: {
      validate: {
        params: Joi.object({ id: Joi.string().required() })
      },
      tags: ['api']
    }
  }
];
