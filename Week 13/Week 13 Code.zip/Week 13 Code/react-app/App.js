import React, { useEffect, useState } from 'react';
import axios from 'axios';
import 'bootstrap/dist/css/bootstrap.min.css';

export default function App() {
  const [data, setData] = useState([]);

  useEffect(() => {
    axios.get('http://localhost:4000/products')
      .then(res => setData(res.data))
      .catch(console.error);
  }, []);

  return (
    <div className="container mt-5">
      <h2 className="mb-4 text-center">Product List</h2>
      <div className="row">
        {data.map((p,i)=>(
          <div key={i} className="col-md-4 mb-3">
            <div className="card shadow">
              <div className="card-body">
                <h5 className="card-title">{p.name}</h5>
                <p className="card-text">${p.price}</p>
                <p className="text-muted">{p.category}</p>
              </div>
            </div>
          </div>
        ))}
      </div>
    </div>
  );
}
