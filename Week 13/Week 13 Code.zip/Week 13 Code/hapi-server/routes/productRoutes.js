const Product = require('../models/Product');

module.exports = [
  {
    method: 'GET',
    path: '/products',
    handler: async () => Product.find()
  },
  {
    method: 'POST',
    path: '/products',
    handler: async (req) => {
      const p = new Product(req.payload);
      return p.save();
    }
  }
];