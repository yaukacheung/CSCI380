const mongoose = require('mongoose');
module.exports = async () => {
  await mongoose.connect('mongodb://localhost:27017/hapi_demo');
  console.log('MongoDB connected');
};