const Hapi = require('@hapi/hapi');
const productRoutes = require('./routes/productRoutes');
const connectDB = require('./config/db');

const init = async () => {
  await connectDB();
  const server = Hapi.server({ port: 4000, host: 'localhost' });
  server.route(productRoutes);
  await server.start();
  console.log('Server running:', server.info.uri);
};

init();